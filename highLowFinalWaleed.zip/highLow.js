let isNum = false;
let n, converNum, finalNum;
let arr = [];


while (!isNum)
{
    n = window.prompt("Enter the maximum number you want to guess from:");
    converNum = Number(n);

    if (!isNaN(converNum) && converNum > 0)
    {
        finalNum = Math.round(converNum);
        isNum = true;
    }
    console.log("Value Entered: " + converNum);
    console.log("Final Value: " + finalNum);
}

let randomNum = Math.floor(Math.random() * finalNum) + 1;

console.log("RNG: " + randomNum);

let maxSelected = document.getElementById("maxSelected");
maxSelected.innerHTML = ("Guess a number between 1 and " + finalNum);

function guess()
{
    let input = Number(document.getElementById("guess").value);
    //let funcIsNum = false;

    console.log(input);

    let output = document.getElementById("result");

    let numCheck = Number(input);
    console.log("converted input: " + numCheck);

    if (!isNaN(numCheck))
    {
        if (numCheck >= 1 && numCheck <= finalNum)
        {
            if (numCheck == randomNum)
            {
                arr.push(numCheck);
                output.innerHTML = "You got it! It took you " + arr.length + " tries and your guesses were " + arr.join(', ');
            }
            else if (numCheck > randomNum)
            {
                if (arr.includes(numCheck))
                {
                    output.innerHTML = "You already guessed that number!"    
                }
                else
                {
                    output.innerHTML = "No, try a lower number";
                    arr.push(numCheck);
                }
            }
            else if (numCheck < randomNum)
            {
                if (arr.includes(numCheck))
                {
                    output.innerHTML = "You already guessed that number!"    
                }
                else
                {
                    output.innerHTML = "No, try a higher number";
                    arr.push(numCheck);
                }
            }
        }
        else if (numCheck < 1 || numCheck > finalNum)
        {
            output.innerHTML = "That number is not in range, try again.";
        }
    }
    else
    {
        output.innerHTML = "That is not a number!";
    }

    /*
    if (input == randomNum)
    {
        output.innerHTML = "You got it!";
    }
    else if (input > randomNum)
    {
        output.innerHTML = "No, try a lower number";
    }
    else if (input < randomNum)
    {
        output.innerHTML = "No, try a higher number";
    }
    */
}